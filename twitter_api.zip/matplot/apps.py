from django.apps import AppConfig


class MatplotConfig(AppConfig):
    name = 'matplot'
