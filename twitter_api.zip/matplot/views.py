import json
import pandas as pd
import matplotlib.pyplot as plt
import io
import urllib, base64

from django.shortcuts import render

dates = []
total_messages = {}

def parse(item):
    return json.loads(item)

def get_amount_messages(item, obj):
    for i in item:
        if i in obj:
            obj[i] += 1
        else:
            obj[i] = 1

# Create your views here.
def home(request):
    with open('data/database.json', 'r') as f:
        data = json.loads(f.read())
        try:
            for index, i in enumerate(data["tweets"]):
                if index == 250:
                    break
                else:
                    date_tweeted = parse(i)['created_at']

                    dates.append(f'{date_tweeted[4:7]}/{date_tweeted[8:10]}/{date_tweeted[26:30]} {date_tweeted[11:16]}')
                    get_amount_messages(dates, total_messages)
        except():
            pass

    data = pd.DataFrame(data=total_messages, index=[1])

    # #create dataframe
    # html = data.to_html()

    # #write html to file
    # text_file = open("matplot/templates/table.html", "w")
    # text_file.write(html)
    # text_file.close()

    # Adds all the values up in the array.
    x = list(total_messages.keys())
    y = list(total_messages.values())

    colors = ["#002fff", "#1e45f5", "#334dc0", "#385bfa", "#657ff1", "#2c99ff", "#0888ff"]

    #Adds colors to the graph and align each bar in the center.
    plt.bar(x, y, color=colors, align='center')
    plt.ylim(0,5000)

    plt.title("Amount of tweets sent over intervals of 1 minute")
    plt.xlabel("Time")
    plt.ylabel("Amount of Tweets")

    # Creates a grid behind the plotted bars.
    plt.grid(b=True, which='minor', color='grey', linestyle='dotted', alpha=0.2)

    # Activates the grid.
    plt.minorticks_on()
    plt.xticks(x, x, rotation='vertical')

    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    string = base64.b64encode(buf.read())
    uri = urllib.parse.quote(string)

    return render(request, 'graph.html', {'data':uri})