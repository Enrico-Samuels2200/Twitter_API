import tweepy
import json

from tweepy import OAuthHandler
from tweepy import Stream
from tweepy.streaming import StreamListener

consumer_key = '7xjklr2l0FCgAjIEM2tgsa7r5'
consumer_secret = '53vFN6V5U6xD835WQV5nbtVWV1WK9mIVXolwHA6b8a89BusftQ'
access_token = '1165879873262497792-uq4iZgTNAjoDbCVbHVWusCgwYQ0Oiv'
access_secret = 'g7Uo4EaopgaNERGYNsEevxfrkxCt9ceH0d6RfnhzUHouQ'

auth = OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_secret)
api = tweepy.API(auth)
 
json_list = []
class MyListener(StreamListener):
    
    def on_data(self, data):
        try:
            
            with open('data/database.json', 'w') as f:
                if data.rstrip(' \r\n') != "":
                    json_list.append(data)

                f.write(json.dumps({"tweets":json_list}, indent=4, sort_keys=True))
                return True

        except BaseException as e:
            print("Error on_data: %s" % str(e))
        return True
 
    def on_error(self, status):
        print(status)
        return True
 

def main():
    twitter_stream = Stream(auth, MyListener())
    twitter_stream.filter(track=['#python'])

if __name__ == "__main__":
    main()